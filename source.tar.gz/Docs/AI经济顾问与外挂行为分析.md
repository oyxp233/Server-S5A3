# AI 经济顾问与外挂行为分析

适用目录：

- `Server-S5A3/go-server`
- `GmTool-S5A3/gateway`

## 一、这次加了什么

新增了一个后端能力：`AI Economy Advisor`。

它会做三件事：

1. 采集每日关键经济事件
2. 按天汇总玩家行为并生成报告
3. 可选地自动调整拍卖行机器人里指定物品的 `referencePrice`

当前已经接入的事件：

- 疲劳消耗
- 深渊完成次数
- 史诗拾取次数
- 地面金币拾取
- NPC 出售物品获得金币
- 玩家交易获得金币
- 拍卖行成交获得金币
- 疲劳药使用
- 深渊/史诗之路入场材料消耗

## 二、外挂分析口径

当前不是读取客户端硬证据，而是做**行为异常分析**。

目前的可疑规则包括：

- 单刷情况下，多次通关但没有观察到技能施放
- 单刷情况下，通关速度异常偏快
- 单刷情况下，同时出现“无技能施放 + 超短通关”

这更适合做：

- 风控预警
- 人工复核名单
- 给登录器反外挂审计做二次筛选

不建议直接拿它当封号依据。

## 三、自动调价口径

当前自动改的是**拍卖行机器人补货清单里的参考价**，不是商城/CERA 价格。

原因：

- 可以直接复用现有拍卖行机器人热更新链路
- 不需要改客户端交易面
- 能最快形成“数据 -> 分析 -> 调价”的闭环

建议把以下物品放进拍卖行机器人补货清单：

- 疲劳药水
- 深渊派对邀请函

然后用环境变量告诉顾问哪些 `itemId` 属于这两类。

## 四、环境变量

### 1. 总开关

```env
DNFBRIDGE_AI_ECON_ENABLED=true
DNFBRIDGE_AI_ECON_DRY_RUN=true
DNFBRIDGE_AI_ECON_AUTO_APPLY=true
DNFBRIDGE_AI_ECON_ANALYZE_BEHAVIOR=true
```

说明：

- `DRY_RUN=true` 时会生成建议，但不会真的改拍卖行参考价
- `AUTO_APPLY=true` 时会自动把建议写回拍卖行机器人清单

### 2. 调度时间

```env
DNFBRIDGE_AI_ECON_RUN_HOUR=6
DNFBRIDGE_AI_ECON_RUN_MINUTE=10
```

默认每天 `06:10` 跑一次，分析**上一服务日**。

### 3. 大模型 API

当前走 OpenAI 兼容的 Chat Completions 接口：

```env
DNFBRIDGE_AI_ECON_API_URL=https://your-provider.example/v1/chat/completions
DNFBRIDGE_AI_ECON_API_KEY=your_api_key
DNFBRIDGE_AI_ECON_MODEL=gpt-4.1-mini
```

如果没配，会自动回退到本地启发式策略。

### 4. 风险控制

```env
DNFBRIDGE_AI_ECON_MAX_DAILY_CHANGE_PERCENT=20
```

表示单日最多只允许把某个参考价改动 `±20%`。

### 5. 物品映射

```env
DNFBRIDGE_AI_ECON_FATIGUE_POTION_ITEM_IDS=10005025,10005026
DNFBRIDGE_AI_ECON_INVITATION_ITEM_IDS=3330,3331
```

这些 `itemId` 会被映射到两类建议价格：

- `fatiguePotionReferencePrice`
- `invitationReferencePrice`

### 6. 报告目录

```env
DNFBRIDGE_AI_ECON_REPORT_DIR=data/ai-economy
```

目录下会写入：

- `events/<service_day>.jsonl`
- `<service_day>.json`
- `latest.json`

## 五、手动接口

网关新增了两个接口：

### 1. 查看状态

`GET /api/v1/hot-update/ai-economy-advisor`

返回：

- 当前配置
- 最新分析报告

### 2. 立即运行

`POST /api/v1/hot-update/ai-economy-advisor/run`

作用：

- 立刻分析上一服务日
- 返回本次报告

## 六、当前限制

1. 现在调的是拍卖行参考价，不是商城标价
2. 金币统计目前覆盖了地面金币、NPC 出售、玩家交易收入、拍卖行成交收入，但仍不是全口径经济核算
3. 外挂识别当前以服务端副本内行为异常为主，不是客户端硬证据

## 七、下一步建议

1. 把商城/CERA 价格表也接成热更新目标
2. 接入登录器反外挂审计日志，形成“客户端证据 + 服务端行为”的双证据链
3. 给 GM 控制台加页面，展示每日报告、可疑账号和本次调价结果
