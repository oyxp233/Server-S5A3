# 队伍中间出现空槽后，空槽之后的成员进图看不到队友模型

状态：2026-11-20 已按第 6 节实现（诊断按第 5 节思路改为复用 ARR1 失败回执的空闲字节），见 `scripts/client/party-registration-by-id/`；离线 Unicorn 验证通过，待实机验收。2026-11-18 整理。

2026-11-19 20:27 又出现一例不需要空槽的情形：队员离队后被邀回原槽位，排在他后面的成员对队长持续回 `3`。同样由按服务端槽位号索引引起，一并覆盖。

## 1. 现象

四人队按槽位 0、1、2、3 排列。槽位 2 的成员在城镇里退队后，剩下三人进普通副本：

- 槽位 0、1 的成员能正常看到全部队友；
- 槽位 3 的成员（空槽之后的那个人）看不到任何队友的人物模型；
- 服务端名单、进图、补发都显示成功，UDP 中继也通。

同一名玩家在没有空槽的队伍里（槽位 0、1、2）进图完全正常。

## 2. 线上证据（客户端 v2.1.5.3，SHA256 `07C2F298…`）

服务端按固定槽位设计，退队不挪位：

- `game-party-dungeon-loading-ready` / `game-party-initial-slot-placement`：`slots=[0 1 3]`，空槽之后的成员 `slot=3`、`local_slot=3`；
- 退队时服务端已向剩余成员发送 `current-party-frame-op9-send source=runtime_party_member_removed`，没有漏发；
- `game-dungeon-party-peer-actor-send/delivered` 与 `bounded_peer_actor_recovery` 对槽位 3 的成员每个房间都补满 6 轮。

`0x7f14` 登记回执（`game-dungeon-party-peer-native-registration`）：

| 回报方 | 查询的队友 | native_status |
| --- | --- | --- |
| 槽位 3 成员 | 槽位 0、槽位 1 | 每次都是 `3`（WrongIdentity），共 24 次，连续多个房间 |
| 槽位 1 成员 | 槽位 3 | 第一次即 `5`（Registered） |

同一时段整份记录里其余 70 次回执都是 `5`；`3` 只出现在空槽之后的成员身上。
槽位 1 的客户端能在槽位 3 登记到对方，说明服务端下发给各端的名单一致；
问题是空槽之后那一端的**客户端自身状态**与服务端的槽位号不再一一对应。

## 3. 客户端里按槽位号比对的位置

两段代码都假设“服务端槽位号 == 客户端队伍记录下标 == 队伍管理器下标”。

### 3.1 登记回执观察器（`scripts/client/party-room-ack/registration.cpp`）

返回 `WrongIdentity` 的条件，按出现顺序：

1. `word(mgr, 0x48 + query[5]*4) != self`：用服务端给的**自身槽位号**直接索引管理器 `[0x56A3768]+0x48`；
2. 队伍记录 `party+0x70` 路由检查（二进制里已由 route-compat 改为 `route > 1` 才拒绝）；
3. 命名空间 `party+0x74` 与 `0x2964680` 不一致；
4. 8 个槽位逐位比较：`party+0x2C+i*4`（`0xFFFF` 视作 0）必须等于查询里的 `query[24+i*2]`；
5. `self+0x20` 必须等于 `query[24 + query[5]*2]`；
6. 队友：`word(mgr, 0x48 + query[6]*4)` 取到的 wrapper，其 `+0x20` 必须等于 `query[24 + query[6]*2]`。

### 3.2 原生队友插入 `processSlot`（v2.1.5.3 `0x6F88669`，由 route-compat 构建脚本登记）

- `ebx` 为槽位号（`cmp ebx,7`）；
- `call 0x2974890(slot)` 从管理器取该槽位 wrapper；
- `0x6F887AF  cmp eax, [edx+ebx*4+0x2c]`：wrapper 的角色 ID 必须等于队伍记录同一下标的 ID。

`processSlot` 自身只用客户端内部的“管理器下标 = 记录下标”，只要传入的是**客户端自己的下标**就成立；
出错的是把服务端槽位号直接当客户端下标用的地方（3.1 的 1、4、5、6，以及调用 `processSlot`/`reconcile` 时传入的槽位）。

## 4. 根因假设（需先用第 5 节的诊断区分）

- **H1 客户端压缩了槽位**：原生 NOTI9 处理成员移除时，把后面的成员往前挪，客户端记录/管理器变成 `[A, B, D, 空]`，服务端仍是 `[A, B, 空, D]`。3.1 的第 1、4 条必然失败。
- **H2 客户端没清掉离队成员**：记录仍是 `[A, B, C, D]`（C 已离队）。3.1 的第 4 条失败。

两者都只影响“空槽之后”的成员，与现象一致；修法不同（H2 还需要服务端在进图前重发完整名单），所以先诊断。

## 5. 第一步：给回执加诊断（客户端 + 服务端各一处小改动）

当前回执固定 80 字节，`body[65..67]` 必须为 0，否则服务端整包丢弃
（`go-server/internal/services/dnfbridge/dungeon_peer_native_registration.go`，`handleDungeonPeerNativeRegistrationReply`）。

建议新增 `ARR2`（向后兼容，`ARR1` 不变）：

| 偏移 | 字节 | 含义 |
| --- | --- | --- |
| 0–79 | 80 | 与 `ARR1` 相同，magic 改为 `ARR2` |
| 65 | 1 | `WrongIdentity` 时的子原因：1 自身槽位不符，2 命名空间，3 记录逐位不符，4 自身 ID 不符，5 队友 wrapper 不符 |
| 80 | 16 | 客户端队伍记录 `party+0x2C` 的 8 个角色 ID（u16，`0xFFFF` 记 0） |
| 96 | 16 | 管理器 `mgr+0x48` 8 个 wrapper 的 `+0x20` 角色 ID（空 wrapper 记 0） |
| 112 | 1 | 客户端在管理器里找到的自身下标（找不到记 8） |

服务端：接受 `ARR2`，`status != 5` 时把子原因、两组 8 槽 ID 和自身下标写进
`game-dungeon-party-peer-native-registration` 事件；`status == 5` 的判定与现在完全相同。

## 6. 第二步：按角色 ID 而不是槽位号对齐（观察器与插入调用方）

1. **自身**：不用 `mgr[query[5]]`，改为扫描 8 个管理器槽找 `wrapper == self`（`registration.cpp` 里 `reconcile` 前已有同样的扫描），记下客户端自身下标 `selfLocal`。再核对 `self+0x20 == query[24+query[5]*2]`。
2. **名单**：不再逐位比较，改为“集合相等”：查询里每个非零 ID 恰好在客户端记录中出现一次（位置不限），客户端记录里每个非零 ID 也恰好在查询里出现一次，非零个数相等。重复 ID、多出或缺少任何 ID 仍返回 `WrongIdentity`。
   - 若诊断证实是 H2（记录里残留离队成员），集合比较会如实失败，不要放宽；此时需服务端在共享加载屏障前对该成员重发完整 `op9` 名单，另立服务端改动。
3. **队友**：用 `peerID = query[24+query[6]*2]` 在管理器里按 `wrapper+0x20` 查找客户端下标 `peerLocal`；找不到返回 `MissingActor`。后续 `wrapper`、`reconcile(peerLocal, …)` 以及调用 `processSlot` 时都传 `peerLocal`，不传 `query[6]`。
4. **保持不变**：路由（`route > 1` 拒绝）、命名空间、`0x111` 类型、房间登记表成员关系、所有固定上下文（room/registry/party/self/epoch）复核、插入后的二次复核，以及只有 `Registered` 才回 5。
5. 若 `processSlot` 还有其它调用方直接使用服务端槽位号（例如 party-room-recovery 的 mode1 检查循环），同样改为按 ID 换算成客户端下标；它内部的 `cmp eax,[edx+ebx*4+0x2c]` 不需要改。

## 7. 验证要求

离线（沿用 `party-room-ack/verify_native.py`、`party-room-route-compat/verify_native.py` 的 Unicorn 夹具）：

- 服务端 `[0,1,_,3]` + 客户端压缩 `[0,1,2,_]`：自身在空槽后、队友在空槽后、两者都在空槽前，三种都必须回 5 并只插入一次；
- 服务端与客户端都 `[0,1,_,3]`（客户端未压缩）：同样回 5；
- 客户端记录残留离队成员（H2）：必须回 3，不得插入；
- 重复 ID、ID 不在名单、换人、路由/命名空间错误、retired 对象：保持原拒绝；
- 原四人全向、三人缺一、晚就绪、幂等用例全部保留并通过；
- 输入 EXE 原样复现“空槽之后回 3”，作为负面对照。

实机：四人组队 → 槽位 2 的成员在城镇退队 → 其余三人进普通副本、过两个房间。
服务端日志里三个方向的 `game-dungeon-party-peer-native-registration` 都应为 `native_status=5`，
`bounded_peer_actor_recovery` 不应每房间补满 6 轮；三端都能看到彼此模型并同步动作。

## 8. 未选的服务端替代方案

服务端在城镇退队时压缩槽位并重发名单，可以绕开此问题，但会改变 UDP 中继腿、进图站位、
房间槽位表依赖的“固定槽位”约定（见 `runtime_manager.go` 的 `addAt` / `leaveLocked` 注释），
本次不采用。
