// Copy into an isolated go-server/cmd/scratch directory before building.
// This is an offline PVF resource tool, not a game server or a deployment tool.
package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	p "longheng.io/server/internal/platform/pvf"
)

const baseline = "70691187212680aed77986519ab3afc02a680409d799baa8116ab03081b1c059"
const catalogPath = "etc/cerashop.etc"
const commodityID = 109949
const itemID = 10007849
const itemPath = "stackable/cash/chn_20150521_Absolute_Bindcube/chn_2015_Absolute_Upper_Bindcube_10007849.stk"

func must(err error) {
	if err != nil {
		panic(err)
	}
}
func require(ok bool, why string) {
	if !ok {
		panic(why)
	}
}
func digest(data []byte) string {
	h := sha256.Sum256(data)
	return hex.EncodeToString(h[:])
}
func token(raw []byte, offset int) (byte, uint32) {
	return raw[offset], binary.LittleEndian.Uint32(raw[offset+1 : offset+5])
}
func section(a *p.Archive, raw []byte, name string) (int, int) {
	start, end := -1, -1
	for offset := 0; offset < len(raw); offset += 5 {
		kind, value := token(raw, offset)
		if kind != 3 {
			continue
		}
		switch a.ResolveString(int(value)) {
		case "[" + name + "]":
			require(start == -1, "duplicate section: "+name)
			start = offset + 5
		case "[/" + name + "]":
			require(start >= 0 && end == -1, "bad section end: "+name)
			end = offset
		}
	}
	require(start >= 0 && end >= start, "missing section: "+name)
	return start, end
}
func writeExclusive(name string, data []byte) {
	file, err := os.OpenFile(name, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	must(err)
	_, err = file.Write(data)
	must(err)
	must(file.Sync())
	must(file.Close())
}

func main() {
	input := flag.String("pvf", "", "matching current input PVF")
	output := flag.String("out", "", "new separate PVF candidate")
	report := flag.String("report", "", "new verification JSON")
	flag.Parse()
	require(*input != "" && *output != "" && *report != "", "all flags required")
	inAbs, err := filepath.Abs(*input)
	must(err)
	outAbs, err := filepath.Abs(*output)
	must(err)
	reportAbs, err := filepath.Abs(*report)
	must(err)
	require(!strings.EqualFold(inAbs, outAbs) && !strings.EqualFold(inAbs, reportAbs) && !strings.EqualFold(outAbs, reportAbs), "paths must differ")
	for _, target := range []string{outAbs, reportAbs} {
		_, err := os.Stat(target)
		require(os.IsNotExist(err), "refusing existing output: "+target)
	}
	base, err := os.ReadFile(inAbs)
	must(err)
	require(digest(base) == baseline, "input PVF changed: rebase recipe before preparing")
	a, err := p.OpenBytes(base)
	must(err)
	itemText, err := a.ReadText(itemPath)
	must(err)
	require(strings.Contains(itemText, "梦想装扮合成器") && strings.Contains(itemText, "黑色战灵天舞"), "unexpected item definition")
	lst, err := a.ReadRaw("stackable/stackable.lst")
	must(err)
	registered := false
	for offset := 0; offset+10 <= len(lst); offset += 10 {
		kind, value := token(lst, offset)
		if kind == 0 && value == itemID {
			pathKind, magic := token(lst, offset+5)
			require(pathKind == 6 && strings.EqualFold("stackable/"+a.ResolveString(int(magic)), itemPath), "wrong item registration")
			registered = true
		}
	}
	require(registered, "item is not registered")
	raw, err := a.ReadRaw(catalogPath)
	must(err)
	require(len(raw)%5 == 0, "invalid catalog token size")
	for offset := 0; offset < len(raw); offset += 5 {
		kind, value := token(raw, offset)
		if kind == 0 {
			require(value != commodityID, "commodity number already referenced")
			require(value != itemID, "item already listed: review instead of duplicating")
		}
	}
	start, end := section(a, raw, "item")
	require((end-start)%45 == 0, "item section must contain nine-token rows")
	labelMagic := -1
	for offset := start + 30; offset < end; offset += 45 {
		kind, value := token(raw, offset)
		if kind == 6 && a.ResolveString(int(value)) == "1个" {
			labelMagic = int(value)
			break
		}
	}
	require(labelMagic >= 0, "missing ordinary one-item label")
	// New row is appended within [item], whose native tab is 道具 -> 道具.
	// Reuse the existing quantity string; preserve all original token bytes.
	row := make([]byte, 45)
	for i, value := range []uint32{commodityID, itemID, 1, 0, 0, 10000, uint32(labelMagic), 0, 0} {
		row[i*5] = 0
		if i == 6 {
			row[i*5] = 6
		}
		binary.LittleEndian.PutUint32(row[i*5+1:], value)
	}
	for _, name := range []string{"buy restrict item", "not stackable buy", "btn control"} {
		begin, finish := section(a, raw, name)
		for offset := begin; offset < finish; offset += 5 {
			kind, value := token(raw, offset)
			require(kind != 0 || value != commodityID, "new commodity is restricted")
		}
	}
	for _, f := range a.Files() {
		if !strings.Contains(strings.ToLower(f.ArchivePath), "cerashophide") {
			continue
		}
		hidden, err := a.ReadRaw(f.ArchivePath)
		must(err)
		if f.DataType != 1 {
			continue
		}
		for offset := 0; offset+5 <= len(hidden); offset += 5 {
			kind, value := token(hidden, offset)
			require(kind != 0 || (value != commodityID && value != itemID), "new product or item is hidden")
		}
	}
	changed := append([]byte{}, raw[:end]...)
	changed = append(changed, row...)
	changed = append(changed, raw[end:]...)
	require(bytes.Equal(changed[:end], raw[:end]) && bytes.Equal(changed[end+len(row):], raw[end:]), "existing tokens changed")
	data, err := a.RepackRaw([]p.RawReplacement{{Path: catalogPath, Data: changed}})
	must(err)
	b, err := p.OpenBytes(data)
	must(err)
	kept, err := a.VerifyRawReplacementPreservation(b, []string{catalogPath})
	must(err)
	got, err := b.ReadRaw(catalogPath)
	must(err)
	require(bytes.Equal(got, changed), "candidate catalog differs from the intended raw stream")
	text, err := b.ReadText(catalogPath)
	must(err)
	require(strings.Contains(text, "109949 10007849 1 0 0 10000 `1个` 0 0"), "candidate text readback failed")
	must(os.MkdirAll(filepath.Dir(outAbs), 0700))
	writeExclusive(outAbs, data)
	delivered, err := p.Open(outAbs)
	must(err)
	keptAgain, err := a.VerifyRawReplacementPreservation(delivered, []string{catalogPath})
	must(err)
	require(kept == keptAgain, "delivered archive preservation differs")
	got, err = delivered.ReadRaw(catalogPath)
	must(err)
	require(bytes.Equal(got, changed), "delivered catalog differs")
	unchangedInput, err := os.ReadFile(inAbs)
	must(err)
	require(digest(unchangedInput) == baseline, "input changed during preparation")
	result := map[string]any{"status": "prepared-not-deployed", "inputSHA256": baseline, "outputSHA256": digest(data), "itemID": itemID, "itemName": "梦想装扮合成器 (黑色战灵天舞)", "commodityID": commodityID, "count": 1, "priceCera": 10000, "category": "道具/道具", "purchaseLimit": "none", "changedPaths": []string{catalogPath}, "addedTokenBytes": 45, "existingCatalogTokensPreserved": true, "unchangedFilesPreserved": kept, "fileCount": a.FileCount(), "inputUnchanged": true, "deployed": false, "gameAcceptance": "pending"}
	encoded, err := json.MarshalIndent(result, "", "  ")
	must(err)
	must(os.MkdirAll(filepath.Dir(reportAbs), 0700))
	writeExclusive(reportAbs, append(encoded, '\n'))
	fmt.Println(string(encoded))
}
