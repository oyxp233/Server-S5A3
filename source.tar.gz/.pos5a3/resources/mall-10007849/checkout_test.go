// Run only in an isolated Linux copy of the current dnfbridge package.
// All purchases below use an in-memory repository, never player data.
package dnfbridge

import (
	"context"
	"os"
	"testing"

	repo "longheng.io/server/internal/modules/dnf/repository"
	memory "longheng.io/server/internal/modules/dnf/repository/memory"
	platformpvf "longheng.io/server/internal/platform/pvf"
)

func TestPrivateMall10007849CandidateRepeatedPurchase(t *testing.T) {
	path := os.Getenv("PRIVATE_MALL_CANDIDATE")
	if path == "" {
		t.Skip("explicit prepared PVF required")
	}
	archive, err := platformpvf.Open(path)
	if err != nil {
		t.Fatal(err)
	}
	catalog, err := newPVFCeraShopCatalog(archive)
	if err != nil {
		t.Fatal(err)
	}
	product, found := catalog.Product(109949)
	if !found || product.ItemID != 10007849 || product.Count != 1 || product.CeraPrice != 10000 || product.Section != "item" {
		t.Fatalf("unexpected product: found=%t %+v", found, product)
	}
	definition, err := catalog.items.ResolveItem(10007849)
	if err != nil {
		t.Fatal(err)
	}
	if definition.Name != "梦想装扮合成器 (黑色战灵天舞)" || definition.AttachType != "[account]" {
		t.Fatalf("wrong item: %+v", definition)
	}
	repos := memory.NewMemoryGroup()
	ctx := context.Background()
	seedShopCharacter(t, ctx, repos, "77", 30000, nil)
	service := shopTestService(repos, catalog)
	session := &gameSession{conn: &bufferConn{}, connID: "private-mall-offline", selectedCharacterID: 77}
	for purchase := 1; purchase <= 3; purchase++ {
		result, err := service.commitCurrentCeraShopPurchase(ctx, session, catalog, currentCeraShopPurchaseRequest{
			PaymentMode: currentCeraShopPaymentModeCera,
			Items:       []currentCeraShopPurchaseRequestItem{{CommodityID: 109949, AttributeValue: 0xff}},
		})
		if err != nil {
			t.Fatalf("purchase %d: %v", purchase, err)
		}
		if result.CeraAfter != int64(30000-purchase*10000) {
			t.Fatalf("wrong wallet after purchase %d: %d", purchase, result.CeraAfter)
		}
		inventory, found, err := repos.Inventory.Load(ctx, "77")
		if err != nil || !found {
			t.Fatalf("inventory found=%t err=%v", found, err)
		}
		var total int64
		for _, stack := range inventory.Slots {
			if stack.ItemID == 10007849 {
				total += stack.Count
			}
		}
		if total != int64(purchase) {
			t.Fatalf("purchase %d delivered total %d", purchase, total)
		}
	}
	before, _, err := repos.Inventory.Load(ctx, "77")
	if err != nil {
		t.Fatal(err)
	}
	_, err = service.commitCurrentCeraShopPurchase(ctx, session, catalog, currentCeraShopPurchaseRequest{
		PaymentMode: currentCeraShopPaymentModeCera,
		Items:       []currentCeraShopPurchaseRequestItem{{CommodityID: 109949, AttributeValue: 0xff}},
	})
	if err == nil {
		t.Fatal("insufficient balance purchase succeeded")
	}
	after, _, err := repos.Inventory.Load(ctx, "77")
	if err != nil {
		t.Fatal(err)
	}
	count := func(inventory repo.InventoryRecord) int64 {
		var n int64
		for _, stack := range inventory.Slots {
			if stack.ItemID == 10007849 {
				n += stack.Count
			}
		}
		return n
	}
	if count(before) != 3 || count(after) != 3 || loadCeraShopAccountCera(t, ctx, repos, "account-1") != 0 {
		t.Fatal("failed purchase changed inventory or wallet")
	}
}
