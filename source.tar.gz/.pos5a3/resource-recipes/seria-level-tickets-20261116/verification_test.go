// Copy into an isolated go-server/internal/services/dnfbridge directory only.
package dnfbridge

import (
	"context"
	"reflect"
	"testing"

	dnfrepo "longheng.io/server/internal/modules/dnf/repository"
)

func TestPrivateSeriaLevelTickets20261116(t *testing.T) {
	shop, items := realPVF535(t)
	for _, tc := range []struct {
		name                   string
		item                   uint32
		count                  uint32
		gold, material         int64
		wantGold, wantMaterial int64
		fail                   bool
	}{
		{"capsules9_rejected", 2683663, 1, 123, 9, 123, 9, true},
		{"capsules10", 2683663, 1, 123, 10, 123, 0, false},
		{"capsules20_batch2", 2683663, 2, 123, 20, 123, 0, false},
		{"gold999999_rejected", 10151463, 1, 999999, 10, 999999, 10, true},
		{"gold1000000", 10151463, 1, 1000000, 10, 0, 10, false},
		{"gold2000000_batch2", 10151463, 2, 2000000, 10, 0, 10, false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			if _, ok := shop.npcItems[2][tc.item]; !ok {
				t.Fatal("not in Seria NPC 2 shop")
			}
			p, err := resolveCurrentNPCShopPricing(shop, items, tc.item)
			if err != nil || !p.Buyable || p.SellGold != 0 || p.PurchaseLimitValue != 0 {
				t.Fatalf("pricing=%+v err=%v", p, err)
			}
			if tc.item == 2683663 {
				if !p.MaterialExchange || p.NeedMaterialItem != 2683667 || p.NeedMaterialCount != 10 || p.ExchangeGold != 0 || p.BuyGold != 0 {
					t.Fatalf("exchange=%+v", p)
				}
			} else if p.MaterialExchange || p.BuyGold != 1000000 {
				t.Fatalf("gold=%+v", p)
			}
			repos := mustCurrentNPCShopRepositories(t, tc.gold, map[string]dnfrepo.ItemStack{"0:121": {ItemID: 2683667, Count: tc.material}})
			ctx := context.Background()
			beforeChar, _, _ := repos.Character.Load(ctx, "19")
			beforeBag, _, _ := repos.Inventory.Load(ctx, "19")
			s := currentNPCShopTestService(repos, shop, items)
			_, err = s.commitCurrentNPCShopBuy(ctx, &gameSession{selectedCharacterID: 19}, shop, items, currentNPCShopBuyRequest{ItemID: tc.item, Count: tc.count, ActorContext: 2})
			if (err != nil) != tc.fail {
				t.Fatalf("failure=%t err=%v", tc.fail, err)
			}
			character, _, _ := repos.Character.Load(ctx, "19")
			bag, _, _ := repos.Inventory.Load(ctx, "19")
			if tc.fail {
				if !reflect.DeepEqual(beforeChar, character) || !reflect.DeepEqual(beforeBag, bag) {
					t.Fatal("failed purchase changed assets")
				}
				return
			}
			if character.Stats["gold"] != tc.wantGold {
				t.Fatalf("gold=%d want=%d", character.Stats["gold"], tc.wantGold)
			}
			var materials int64
			for _, stack := range bag.Slots {
				if stack.ItemID == 2683667 {
					materials += stack.Count
				}
			}
			if materials != tc.wantMaterial {
				t.Fatalf("capsules=%d want=%d", materials, tc.wantMaterial)
			}
			assertCurrentNPCShopInventoryAmount(t, bag, int64(tc.item), int64(tc.count))
		})
	}
}
