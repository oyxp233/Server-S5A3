// Run from a temporary command directory inside go-server; never edits its input.
package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"

	"longheng.io/server/internal/platform/pvf"
)

const baseline = "a3cb400aa1aeef1ef89af492c50f588efa096b050ae5c2d5df58368a96744a77"

var paths = []string{
	"itemshop/(r)equipmentshop7.shp",
	"stackable/event/chn_event_20140527_ghost_level_reservate/chn_ghost_level_reservate_2683663.stk",
	"stackable/10151001/10151463.stk",
}

func must(err error) {
	if err != nil {
		panic(err)
	}
}
func check(ok bool, reason string) {
	if !ok {
		panic(reason)
	}
}
func hash(b []byte) string { s := sha256.Sum256(b); return hex.EncodeToString(s[:]) }
func integer(n uint32) []byte {
	b := make([]byte, 5)
	binary.LittleEndian.PutUint32(b[1:], n)
	return b
}
func key(a *pvf.Archive, raw []byte, name string) int {
	check(len(raw)%5 == 0, "non-token script")
	for i := 0; i < len(raw); i += 5 {
		if raw[i] == 3 && a.ResolveString(int(binary.LittleEndian.Uint32(raw[i+1:i+5]))) == name {
			return i
		}
	}
	return -1
}

func main() {
	check(len(os.Args) == 4, "usage: tool INPUT OUTPUT REPORT")
	check(os.Args[1] != os.Args[2], "separate output required")
	_, e := os.Stat(os.Args[2])
	check(os.IsNotExist(e), "output must not exist")
	input, e := os.ReadFile(os.Args[1])
	must(e)
	check(hash(input) == baseline, "baseline mismatch; review latest cumulative PVF before applying")
	a, e := pvf.OpenBytes(input)
	must(e)
	ref, e := a.ReadRaw("stackable/private_seria_exchange/birth_seed_990030101.stk")
	must(e)
	k := func(name string) []byte {
		i := key(a, ref, name)
		check(i >= 0, "missing reference key: "+name)
		return append([]byte(nil), ref[i:i+5]...)
	}
	originals := make([][]byte, len(paths))
	for i, p := range paths {
		originals[i], e = a.ReadRaw(p)
		must(e)
	}
	shop := originals[0]
	start, end := key(a, shop, "[item list]"), key(a, shop, "[/item list]")
	check(start >= 0 && end > start, "shop activity list missing")
	// Bind insertion to the existing first tab, retaining all other tab contents.
	expected := []uint32{490701310, 2683263, 2683265, 2683266, 2683267, 400330062, 990027003, 490009949, 10005308}
	check(end-start == 5*(len(expected)+1), "activity list changed")
	for i, n := range expected {
		check(bytes.Equal(shop[start+5+i*5:start+10+i*5], integer(n)), "activity item mismatch")
	}
	newShop := append([]byte(nil), shop[:end]...)
	newShop = append(newShop, integer(2683663)...)
	newShop = append(newShop, integer(10151463)...)
	newShop = append(newShop, shop[end:]...)
	updates := [][]byte{newShop}
	for i, raw := range originals[1:] {
		for _, name := range []string{"[price]", "[value]", "[need material]", "[purchase limit]"} {
			check(key(a, raw, name) == -1, "existing commerce definition requires review: "+name)
		}
		v := append([]byte(nil), raw...)
		v = append(v, k("[price]")...)
		price := uint32(0)
		if i == 1 {
			price = 1000000
		}
		v = append(v, integer(price)...)
		// Preserve the original zero NPC resale value when introducing a buy price.
		v = append(v, k("[value]")...)
		v = append(v, integer(0)...)
		if i == 0 {
			v = append(v, k("[need material]")...)
			v = append(v, integer(2683667)...)
			v = append(v, integer(10)...)
			v = append(v, k("[/need material]")...)
		}
		updates = append(updates, v)
	}
	r := make([]pvf.RawReplacement, len(paths))
	for i, p := range paths {
		r[i] = pvf.RawReplacement{Path: p, Data: updates[i]}
	}
	output, e := a.RepackRaw(r)
	must(e)
	b, e := pvf.OpenBytes(output)
	must(e)
	unchanged, e := a.VerifyRawReplacementPreservation(b, paths)
	must(e)
	for i, p := range paths {
		raw, e := b.ReadRaw(p)
		must(e)
		check(bytes.Equal(raw, updates[i]), "replacement mismatch: "+p)
	}
	must(os.WriteFile(os.Args[2], output, 0644))
	report := map[string]any{"inputSHA256": hash(input), "outputSHA256": hash(output), "outputBytes": len(output), "changedPaths": paths, "unchangedFiles": unchanged, "hashAndStringTablesPreserved": true, "deployed": false, "rules": []any{
		map[string]any{"item": 2683663, "count": 1, "material": 2683667, "materialCount": 10, "gold": 0, "resaleGold": 0},
		map[string]any{"item": 10151463, "count": 1, "gold": 1000000, "resaleGold": 0},
	}}
	j, e := json.MarshalIndent(report, "", "  ")
	must(e)
	must(os.WriteFile(os.Args[3], append(j, '\n'), 0644))
	fmt.Println(string(j))
}
