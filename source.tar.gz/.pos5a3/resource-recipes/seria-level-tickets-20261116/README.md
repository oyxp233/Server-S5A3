# 赛利亚活动栏升级券

仅修改 PVF，未部署。商店脚本 `itemshop/(r)equipmentshop7.shp` 的首个“活动”列表末尾追加两项：

| 商品 | 每份 | 材料 | 金币 |
| --- | ---: | --- | ---: |
| 2683663（Lv1 升级券，Lv1～79） | 1 | 2683667 ×10 | 0 |
| 10151463（猫猫拳升级券，Lv1～89） | 1 | 无 | 1,000,000 |

两张券保留原始使用、绑定、等级、有效期等定义，不新增限购。显式设置 `[value] 0` 保留原先零 NPC 回售价，避免新增买价使服务端回退为买价的五分之一。2683663 的顶层 `[need material]` 仅用于商店兑换，使用升级券不会再扣材料。2683667 定义不改。

## 重建

`main.go` 仅允许从指定累计 PVF 生成独立输出，输入 SHA256 必须为 `a3cb400aa1aeef1ef89af492c50f588efa096b050ae5c2d5df58368a96744a77`。若上线前 PVF 有其他更新，应重新审查并合并，不能覆盖新累计资源。

在隔离 Linux 源码树，将 `main.go` 复制至 `go-server/cmd/scratch/seria-level-tickets-20261116/main.go`，从 `go-server` 运行：

```sh
go run ./cmd/scratch/seria-level-tickets-20261116 INPUT.pvf OUTPUT.pvf receipt.json
```

工具验证原列表与商业字段前置条件，直接插入原始 token，沿用字符串偏移；调用 `VerifyRawReplacementPreservation` 确认全部其他文件、哈希表、字符串表和未涉及的压缩块保留。

本次候选 SHA256 为 `b9455e2bb33fe0f2d63d14635fae4f41ff975893e2802a3b319cbcbc83e544eb`，126,300,746 字节。仅三个文件改变，其他 1,126,485 个文件保持原样。

## 验证与上线

`verification_test.go` 是隔离验证夹具，将其复制到隔离源码树的 `go-server/internal/services/dnfbridge/private_seria_20261116_test.go`，只在远端运行：

```sh
DNFBRIDGE_REAL_PVF_SMOKE=/absolute/path/OUTPUT.pvf go test ./internal/services/dnfbridge -run '^TestPrivateSeriaLevelTickets20261116$' -count=1 -v
```

使用内存仓储，不连接生产角色数据库。覆盖 NPC 2 商品归属、定价、9/10 个胶囊、999999/1000000 金币的边界、批量两份、失败无扣款及零回售价。本机不运行 dnfbridge 测试。

本次远端上述 6 个分支全部通过；远端 `scripts/check_server_boundary.py` 也通过。本机回收的候选文件 SHA256 与远端回执一致。准备前后实际拉取 GitHub 权威 master，仍为 `be313414`，当前累计提交 `dfc9df6a` 已包含该主干。原始回执和测试日志在 ignored 的本地 `runtime/seria-level-tickets-20261116/` 与远端 `/home/ubuntu/seria-level-tickets-20261116/`。

本地候选放在 `runtime/seria-level-tickets-20261116/candidate/Script.pvf`，玩家原文件保持不变。上线需另行同步游戏、网关（含实际 COS 玩家下载源）及 GM 的 PVF，并按现有流程重启加载资源；无需修改或发布 EXE、服务端二进制。实机商店显示和购买验收留待上线后进行。
