# 练级少女黄金成长胶囊价格

等待运营通知部署；本次不发布、不替换玩家文件、不重启服务。

| 项目 | 规则 |
| --- | --- |
| NPC | 20471，练级少女 |
| 商店 | `itemshop/chn_event_decision_and_decision.shp` |
| 商品 | 490702738，宇尤的黄金成长胶囊 |
| 每份数量 | 1 |
| 硬币 | 490009268 ×100 |
| 新增金币 | 50,000,000 |
| NPC 回售价 | 0，保留原值 |

仅在 `stackable/cash/chn_490702738.stk` 末尾追加 `[price] 50000000`、`[value] 0`。原始商品 token、商店商品列表、绑定、使用等级、直升 90 级、有效期和其他所有条目保持。显式零回售价避免服务端在没有 `[value]` 时按新买价五分之一计算回售价。

现有服务端 `npc_shop_pvf.go` 已解析材料与金币组合价格，`npc_shop_projection.go` 在同一购买事务中扣除两项费用，因此无需修改服务端业务代码或 EXE。黄金胶囊使用流程不处理顶层商店兑换价格，不会在使用时再次扣款。

## 重建

固定输入 SHA256：`f1655ea7790d011830273b01998e14d9e92a57f748ab46be0b5217d559b892c5`，与 2026-11-17 本次核实的线上和本机游戏 PVF 一致。输入变化必须重新审查并合并，不能用本候选覆盖新的累计资源。

在独立 Linux 源码目录，将 `main.go` 放到 `go-server/cmd/scratch/golden-capsule-price-20261117/main.go`，从 `go-server` 运行：

```sh
go run ./cmd/scratch/golden-capsule-price-20261117 INPUT.pvf OUTPUT.pvf receipt.json
```

输入输出必须分离，输出和回执拒绝覆盖。工具核验 NPC、完整商品列表及原硬币数量；复用现有字符串 token，生成后读回并验证全部其他文件、HASH、字符串表和未涉及压缩块保留。

## 验证

`verification_test.go` 仅复制至远端隔离源码树的 `go-server/internal/services/dnfbridge/private_golden_capsule_price_20261117_test.go`，不在本机运行。使用候选真实 PVF、内存仓储，不连接生产数据库：

```sh
DNFBRIDGE_REAL_PVF_SMOKE=/absolute/path/OUTPUT.pvf go test ./internal/services/dnfbridge -run '^TestPrivateGoldenCapsulePrice20261117$' -count=1 -v
```

覆盖金币不足、硬币不足、两者均不足、刚好满足、有余量、批量两份不足和刚好满足，失败时检查角色与背包完整保持。测试不替代上线后的商店显示与实际购买验收。

部署时需同步服务端、网关/COS 玩家更新源及 GM 的 PVF，并按当时的最新资源基线准备加载切换；本次没有执行这些操作。

## 本次结果

- 候选：`runtime/golden-capsule-price-20261117/candidate/Script.pvf`，124,386,222 字节。
- SHA256：`72b95022648ff99f7bfba988522974689693bf5b7d808aeab53b2c555e5302dc`。
- 仅目标道具定义改变；另外 1,126,536 个文件、HASH、字符串表及未涉及压缩块保留，原商品所有 token 保留。
- 在本服源码 `32f82a9a` 的远端独立目录 `/home/ubuntu/golden-capsule-price-20261117/` 上运行上述专项，8 个分支全部通过；仓储为内存实现。
- 本地候选与远端生成回执 SHA256 一致，本地只读工具读回 `[need material] 490009268 100`、`[price] 50000000`、`[value] 0`。回执及测试日志在同一本地 runtime 目录。
- 未部署、未推送网关/COS、未替换玩家本机 PVF，未重启服务。
