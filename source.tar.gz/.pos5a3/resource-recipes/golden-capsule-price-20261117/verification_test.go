// Only run in an isolated Linux source tree, never on the player's local machine.
package dnfbridge

import (
	"context"
	"reflect"
	"testing"

	dnfrepo "longheng.io/server/internal/modules/dnf/repository"
)

func TestPrivateGoldenCapsulePrice20261117(t *testing.T) {
	shop, items := realPVF535(t)
	if _, ok := shop.npcItems[20471][490702738]; !ok {
		t.Fatal("capsule missing from level girl shop")
	}
	pricing, err := resolveCurrentNPCShopPricing(shop, items, 490702738)
	if err != nil || !pricing.Buyable || !pricing.MaterialExchange || pricing.NeedMaterialItem != 490009268 || pricing.NeedMaterialCount != 100 || len(pricing.AdditionalMaterials) != 0 || pricing.ExchangeGold != 50000000 || pricing.SellGold != 0 || pricing.PurchaseLimitValue != 0 {
		t.Fatalf("pricing=%+v err=%v", pricing, err)
	}
	for _, tc := range []struct {
		name                             string
		count                            uint32
		gold, coins, wantGold, wantCoins int64
		fail                             bool
	}{
		{"gold_short", 1, 49999999, 100, 49999999, 100, true},
		{"coins_short", 1, 50000000, 99, 50000000, 99, true},
		{"both_short", 1, 49999999, 99, 49999999, 99, true},
		{"exact", 1, 50000000, 100, 0, 0, false},
		{"surplus", 1, 50000001, 101, 1, 1, false},
		{"batch_gold_short", 2, 99999999, 200, 99999999, 200, true},
		{"batch_coins_short", 2, 100000000, 199, 100000000, 199, true},
		{"batch_exact", 2, 100000000, 200, 0, 0, false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			repos := mustCurrentNPCShopRepositories(t, tc.gold, map[string]dnfrepo.ItemStack{"0:121": {ItemID: 490009268, Count: tc.coins}})
			ctx := context.Background()
			beforeChar, _, _ := repos.Character.Load(ctx, "19")
			beforeBag, _, _ := repos.Inventory.Load(ctx, "19")
			s := currentNPCShopTestService(repos, shop, items)
			_, err := s.commitCurrentNPCShopBuy(ctx, &gameSession{selectedCharacterID: 19}, shop, items, currentNPCShopBuyRequest{ItemID: 490702738, Count: tc.count, ActorContext: 20471})
			if (err != nil) != tc.fail {
				t.Fatalf("fail=%t err=%v", tc.fail, err)
			}
			character, _, _ := repos.Character.Load(ctx, "19")
			bag, _, _ := repos.Inventory.Load(ctx, "19")
			if tc.fail {
				if !reflect.DeepEqual(beforeChar, character) || !reflect.DeepEqual(beforeBag, bag) {
					t.Fatal("failed purchase changed assets")
				}
				return
			}
			if character.Stats["gold"] != tc.wantGold {
				t.Fatalf("gold=%d want=%d", character.Stats["gold"], tc.wantGold)
			}
			var coins int64
			for _, stack := range bag.Slots {
				if stack.ItemID == 490009268 {
					coins += stack.Count
				}
			}
			if coins != tc.wantCoins {
				t.Fatalf("coins=%d want=%d", coins, tc.wantCoins)
			}
			assertCurrentNPCShopInventoryAmount(t, bag, 490702738, int64(tc.count))
		})
	}
}
