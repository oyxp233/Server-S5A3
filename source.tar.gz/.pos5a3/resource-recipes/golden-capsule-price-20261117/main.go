// Run inside an isolated go-server command directory. Never edits the input.
package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"

	"longheng.io/server/internal/platform/pvf"
)

const baseline = "f1655ea7790d011830273b01998e14d9e92a57f748ab46be0b5217d559b892c5"
const itemPath = "stackable/cash/chn_490702738.stk"
const shopPath = "itemshop/chn_event_decision_and_decision.shp"

func must(err error) {
	if err != nil {
		panic(err)
	}
}
func check(ok bool, why string) {
	if !ok {
		panic(why)
	}
}
func hash(b []byte) string { s := sha256.Sum256(b); return hex.EncodeToString(s[:]) }
func integer(n uint32) []byte {
	b := make([]byte, 5)
	binary.LittleEndian.PutUint32(b[1:], n)
	return b
}
func keys(a *pvf.Archive, raw []byte, name string) []int {
	check(len(raw)%5 == 0, "non-token script")
	var result []int
	for i := 0; i < len(raw); i += 5 {
		if raw[i] == 3 && a.ResolveString(int(binary.LittleEndian.Uint32(raw[i+1:i+5]))) == name {
			result = append(result, i)
		}
	}
	return result
}
func one(a *pvf.Archive, raw []byte, name string) int {
	indices := keys(a, raw, name)
	check(len(indices) == 1, "expected exactly one "+name)
	return indices[0]
}

func main() {
	check(len(os.Args) == 4, "usage: tool INPUT OUTPUT REPORT")
	check(os.Args[1] != os.Args[2], "separate output required")
	_, err := os.Stat(os.Args[2])
	check(os.IsNotExist(err), "output must not exist")
	_, err = os.Stat(os.Args[3])
	check(os.IsNotExist(err), "report must not exist")
	input, err := os.ReadFile(os.Args[1])
	must(err)
	check(hash(input) == baseline, "baseline mismatch; review latest cumulative PVF")
	a, err := pvf.OpenBytes(input)
	must(err)
	raw, err := a.ReadRaw(itemPath)
	must(err)
	shop, err := a.ReadRaw(shopPath)
	must(err)
	npc := one(a, shop, "[NPC]")
	check(bytes.Equal(shop[npc+5:npc+10], integer(20471)), "NPC changed")
	start, end := one(a, shop, "[item list]"), one(a, shop, "[/item list]")
	wantItems := []uint32{490009269, 490009270, 490009271, 490009274, 490009275, 490702738}
	check(end-start == (len(wantItems)+1)*5, "shop list changed")
	for i, id := range wantItems {
		check(bytes.Equal(shop[start+5+i*5:start+10+i*5], integer(id)), "shop item changed")
	}
	material, materialEnd := one(a, raw, "[need material]"), one(a, raw, "[/need material]")
	check(materialEnd-material == 15, "material shape changed")
	check(bytes.Equal(raw[material+5:materialEnd], append(integer(490009268), integer(100)...)), "expected 100 original coins")
	for _, field := range []string{"[price]", "[value]"} {
		check(len(keys(a, raw, field)) == 0, "existing field requires review: "+field)
	}
	// Reuse existing key tokens; preserve the archive's string table exactly.
	ref, err := a.ReadRaw("stackable/private_seria_exchange/birth_seed_990030101.stk")
	must(err)
	updated := append([]byte(nil), raw...)
	for _, field := range []struct {
		name  string
		value uint32
	}{{"[price]", 50000000}, {"[value]", 0}} {
		i := one(a, ref, field.name)
		updated = append(updated, ref[i:i+5]...)
		updated = append(updated, integer(field.value)...)
	}
	output, err := a.RepackRaw([]pvf.RawReplacement{{Path: itemPath, Data: updated}})
	must(err)
	b, err := pvf.OpenBytes(output)
	must(err)
	unchanged, err := a.VerifyRawReplacementPreservation(b, []string{itemPath})
	must(err)
	reread, err := b.ReadRaw(itemPath)
	must(err)
	check(bytes.Equal(reread, updated), "replacement mismatch")
	check(bytes.Equal(reread[:len(raw)], raw), "original item tokens changed")
	shopAfter, err := b.ReadRaw(shopPath)
	must(err)
	check(bytes.Equal(shopAfter, shop), "shop unexpectedly modified")
	for _, field := range []struct {
		name  string
		value uint32
	}{{"[price]", 50000000}, {"[value]", 0}} {
		i := one(b, reread, field.name)
		check(bytes.Equal(reread[i+5:i+10], integer(field.value)), "invalid commerce value")
	}
	must(os.WriteFile(os.Args[2], output, 0644))
	report := map[string]any{
		"inputSHA256": hash(input), "outputSHA256": hash(output), "outputBytes": len(output),
		"changedPaths": []string{itemPath}, "unchangedFiles": unchanged,
		"originalTokensPreserved": true, "hashAndStringTablesPreserved": true,
		"item": 490702738, "npc": 20471, "count": 1, "material": 490009268,
		"materialCount": 100, "gold": 50000000, "resaleGold": 0, "deployed": false,
	}
	j, err := json.MarshalIndent(report, "", "  ")
	must(err)
	must(os.WriteFile(os.Args[3], append(j, '\n'), 0644))
	fmt.Println(string(j))
}
