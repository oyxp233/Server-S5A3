@echo off
setlocal
cd /d "%~dp0"
call deploy\windows\resolve_python.bat
if errorlevel 1 exit /b 1
%PYTHON_EXE% deploy\docker\manage.py %*
exit /b %errorlevel%
