@echo off
setlocal
cd /d "%~dp0"
call deploy\windows\resolve_python.bat
if errorlevel 1 (
  pause
  exit /b 1
)
%PYTHON_EXE% deploy\windows\local_client.py
if errorlevel 1 pause
